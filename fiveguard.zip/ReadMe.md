Hello, We're the fiveguard creators Ciastekbatak and Szpachlan at this point we want to thank you for purchasing fiveguard.
It's mean a lot for us that we can provide fivem protection, make living of it and provide you the best experience ever. 
I would like to remind you that you can join our exclusive community by claiming customer rank after purchase!
https://docs.fiveguard.net/customer-rank 
tutorial how to do so

Satisfied with script and want to support us?
We would be very glad if you recommend us to your friendS you can also post our ad in your discord

Are you a server owner? Looking for anticheat? 
**Visit : https://fiveguard.net/ for a decent anticheat for your server **
https://www.youtube.com/watch?v=l1W-o2nvj5E
https://discord.gg/fiveguard

----------- FAQ -----------

How to install?
https://youtu.be/WaShpj4p_Fo

How to allow my dev to edit my config?
https://docs.fiveguard.net/sub-users

How do I protect my TriggerServerEvents?
https://docs.fiveguard.net/safe-events

How do I avoid my server staff getting banned?
https://docs.fiveguard.net/permission-system

Answers to most common questions : 
https://docs.fiveguard.net/faq